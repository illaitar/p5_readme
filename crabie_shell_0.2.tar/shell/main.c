#include <stdio.h>
#include <unistd.h>
#include "stack.h"
#include "poliz.h"
#include "syntax.h"
#include <sys/wait.h>
int 
main(int argc, char **argv)
{
    int z = 0;
    while (1){
        printf("\n=>");
        get_next_line();
        z++;
        int status;
        for (int k = 0;(( k < z) || (k < 5)); ++k){
            int err = waitpid(-1, &status, WNOHANG);
            if (err != -1){
                z --;
            }
        }
    }
    return 0;
}
