#ifndef SYNTAX
#define SYNTAX
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "poliz.h"
#include "float.h"

int get_next_line(void);

#endif
